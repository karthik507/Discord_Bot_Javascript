const Discord = require("discord.js")
const fetch = require("node-fetch")

const keepAlive = require("./server")

const { Client, GatewayIntentBits } = require('discord.js')
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    // ...
  ]
})
const db = require("@replit/database")
const sadWords = ["sad", "depresses", "unhappy", "angry"]
const starterEncouragements = [
  "Cheer up!",
  "Hang in there,",
  "your are a great person bot!"
]
db.get("encouragements").then(encouragements => {
  if (!encouragements || encouragements.length < 1) {
    db.set("encouragements", starterEncouragements)
  }
})

function updateEncouragements(encouragingMessage) {
  db.get("encouragements").then(encouragements => {
    encouragements.push([encouragingMessage])
    db.set("encouragements", encouragements)
  })
}

function deleteEncouragment(index) {
  db.get("encouragements").then(encouragements => {
    if (encouragements.length > index) {
      encouragements.splice(index, 1)
      db.set("encouragements", encouragements)
    }

  })
}

function getQuote() {
  return fetch("https://zenquotes.io/api/random")
    .then(res => {
      return res.json()
    })
    .then(data => {
      return data[0]["q"] + " -" + data[0]["a"]
    })
}

client.on("ready", () => {
  console.log(`logged in as ${client.user.tag}!`)
})

client.on("message", msg => {
  if (msg.author.bot) return

  if (msg.content == "$inspire") {
    getQuote().then(quote => msg.channel.send(quote))
  }


  if (sadWords.some(word => msg.content.includes(word))) {
    db.get("encouragements").then(encouragement => {
      const encouragement =
        encouragements[Math.floor(Math.random() *
          encouragements.length)]
      msg.reply(encouragement)
    })

  }
  if (msg.content.startsWith("$new")) {
    encouragingMessage = msg.content.split("$new")[1]
    updateEncouragements(encouragingMessage)
    msg.channel.send("New Encouraging message added.")
  }
  if (msg.content.startsWith("del")) {
    index = parseInt(msg.content.split("del")[1])
    deleteEncouragment(index)
    msg.channel.send("New Encouraging message deleted.")
  }
})

keepAlive()
const mySecret = process.env['TOKEN']
client.login(mySecret)